import React, { useState } from 'react';
import { View, Image, Text, StyleSheet, ScrollView, TouchableOpacity, FlatList, ActivityIndicator } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import { observer } from "mobx-react-lite";
import { useStores } from "../useStores";

const OrderDetailScreen = observer(() => {
  const { ordersStore, authStore } = useStores();
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const route = useRoute();
  const { orderId } = route.params;
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  const order = ordersStore.orders.find(o => o.id === orderId);

  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return dateString;
      
      const day = date.getDate().toString().padStart(2, '0');
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const year = date.getFullYear();
      const hours = date.getHours().toString().padStart(2, '0');
      const minutes = date.getMinutes().toString().padStart(2, '0');
      
      return `${day}.${month}.${year}, ${hours}:${minutes}`;
    } catch (e) {
      return dateString;
    }
  };

  const handleCancelOrder = async () => {
    try {
      setLoading(true);
      await ordersStore.cancelOrder(authStore.token, orderId);
      navigation.goBack();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePayOrder = () => {
    // Здесь будет логика перехода на оплату
    navigation.navigate('Payment', { orderId });
  };

const renderProductItem = ({ item }) => (
  <View style={styles.productItem}>
    {item.image_url ? (
      <Image 
        source={{ uri: item.image_url }}
        style={styles.productImage}
        resizeMode="contain"
      />
    ) : (
      <View style={styles.productImagePlaceholder}>
        <Icon name="image" size={40} color="#ccc" />
      </View>
    )}
    <View style={styles.productInfo}>
      <Text style={styles.productName} numberOfLines={2}>{item.name}</Text>
      <Text style={styles.productPrice}>{item.price} ₽ × {item.quantity}</Text>
    </View>
    <Text style={styles.productTotal}>{item.price * item.quantity} ₽</Text>
  </View>
);

  if (!order) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center' }]}>
        <Icon name="error-outline" size={50} color="#FF3B30" />
        <Text style={styles.errorText}>Заказ не найден</Text>
      </View>
    );
  }

  return (
    <ScrollView 
      style={[styles.container, { paddingTop: insets.top }]}
      contentContainerStyle={styles.contentContainer}
    >
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Icon name="arrow-back" size={24} color="#4E9F3D" />
        </TouchableOpacity>
        <Text style={styles.title}>Заказ №{order.order_number}</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.statusContainer}>
        <Text style={[
          styles.statusText,
          order.status === 'Отменён (Удален)' && styles.statusCancelled,
          order.status === 'Завершен' && styles.statusDelivered
        ]}>
          {order.status}
        </Text>
        <Text style={styles.orderDate}>{formatDate(order.created_at)}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Товары</Text>
        <FlatList
          data={order.items}
          renderItem={renderProductItem}
          keyExtractor={item => item.id.toString()}
          scrollEnabled={false}
        />
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Информация о заказе</Text>
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Способ доставки:</Text>
          <Text style={styles.infoValue}>{order.delivery_method || 'Не указано'}</Text>
        </View>
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Способ оплаты:</Text>
          <Text style={styles.infoValue}>{order.payment_method || 'Не указано'}</Text>
        </View>
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Адрес доставки:</Text>
          <Text style={styles.infoValue}>{order.delivery_address || 'Не указано'}</Text>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Итого</Text>
        
        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>Товары:</Text>
          <Text style={styles.totalValue}>{order.total_amount} ₽</Text>
        </View>
        
        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>Доставка:</Text>
          <Text style={styles.totalValue}>{order.delivery_cost || 0} ₽</Text>
        </View>
        
        <View style={[styles.totalRow, styles.finalTotal]}>
          <Text style={styles.finalTotalLabel}>Общая сумма:</Text>
          <Text style={styles.finalTotalValue}>
            {order.total_amount} ₽
          </Text>
        </View>
      </View>

      {order.status === 'Новый' && (
        <View style={styles.actionsContainer}>
          <TouchableOpacity 
            style={[styles.actionButton, styles.payButton]}
            onPress={handlePayOrder}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.actionButtonText}>Оплатить заказ</Text>
            )}
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.actionButton, styles.cancelButton]}
            onPress={handleCancelOrder}
            disabled={loading}
          >
            <Text style={[styles.actionButtonText, styles.cancelButtonText]}>Отменить заказ</Text>
          </TouchableOpacity>
        </View>
      )}

      {error && (
        <View style={styles.errorContainer}>
          <Text style={styles.errorMessage}>{error}</Text>
        </View>
      )}
    </ScrollView>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  contentContainer: {
    paddingBottom: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  statusContainer: {
    backgroundColor: '#fff',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  statusText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4E9F3D',
    marginBottom: 4,
  },
  statusCancelled: {
    color: '#FF3B30',
  },
  statusDelivered: {
    color: '#007AFF',
  },
  orderDate: {
    fontSize: 14,
    color: '#666',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 8,
    margin: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 16,
  },
  productItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
productImage: {
  width: 60,
  height: 60,
  borderRadius: 8,
  marginRight: 12,
},
productImagePlaceholder: {
  width: 60,
  height: 60,
  borderRadius: 8,
  backgroundColor: '#f0f0f0',
  justifyContent: 'center',
  alignItems: 'center',
  marginRight: 12,
},
productBrand: {
  fontSize: 12,
  color: '#666',
  marginBottom: 4,
},
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 14,
    color: '#333',
    marginBottom: 4,
  },
  productPrice: {
    fontSize: 13,
    color: '#666',
  },
  productTotal: {
    fontSize: 15,
    fontWeight: '600',
    color: '#333',
    marginLeft: 12,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  infoLabel: {
    fontSize: 14,
    color: '#666',
  },
  infoValue: {
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
    flex: 1,
    marginLeft: 16,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  totalLabel: {
    fontSize: 14,
    color: '#666',
  },
  totalValue: {
    fontSize: 14,
    color: '#333',
  },
  finalTotal: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  finalTotalLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  finalTotalValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  actionsContainer: {
    paddingHorizontal: 16,
    marginTop: 8,
  },
  actionButton: {
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  payButton: {
    backgroundColor: '#4E9F3D',
  },
  cancelButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#FF3B30',
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  cancelButtonText: {
    color: '#FF3B30',
  },
  errorContainer: {
    padding: 16,
    alignItems: 'center',
  },
  errorMessage: {
    color: '#FF3B30',
    fontSize: 14,
    textAlign: 'center',
  },
  errorText: {
    fontSize: 16,
    color: '#FF3B30',
    marginTop: 16,
  },
});

export default OrderDetailScreen;
import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, RefreshControl, ActivityIndicator, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { observer } from "mobx-react-lite";
import { useStores } from "../useStores";
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import CustomHeader from "../components/CustomHeader";

const ITEMS_PER_PAGE = 20;

const statusColors = {
  'Новый': '#FFEE58',
  'Товар зарезервирован': '#B3C1FD',
  'Готов к выдаче': '#66BB6A',
  'Выдан': '#81C784',
  'Отменён (Удален)': '#FFC8C8',
  'Отменён (Возврат товара)': '#FFC8C8',
  'Завершен': '#A5D6A7',
  'default': '#FFFFFF'
};

const paymentMethodLabels = {
  'cash': 'Наличными',
  'card': 'Картой',
  'online': 'Онлайн',
  'default': 'Не указано'
};

const AdminOrdersScreen = observer(() => {
  const { authStore } = useStores();
  const insets = useSafeAreaInsets();
   const navigation = useNavigation();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  const fetchOrders = useCallback(async (currentPage = 1, isRefreshing = false) => {
    try {
      if (isRefreshing) {
        setRefreshing(true);
      } else if (currentPage === 1) {
        setLoading(true);
      }

      const response = await fetch('https://api.koleso.app/api/adminOrders.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authStore.token}`
        },
        body: JSON.stringify({
          store_id: authStore.admin?.storeId,
          page: currentPage,
          per_page: ITEMS_PER_PAGE
        })
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Ошибка загрузки заказов');
      }

      if (isRefreshing || currentPage === 1) {
        setOrders(data.orders);
      } else {
        setOrders(prev => {
          const existingIds = new Set(prev.map(order => order.id));
          const newOrders = data.orders.filter(order => !existingIds.has(order.id));
          return [...prev, ...newOrders];
        });
      }

      setHasMore(data.orders.length === ITEMS_PER_PAGE);
      setError(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [authStore.token, authStore.admin?.storeId]);

  const loadMore = useCallback(() => {
    if (!loading && hasMore) {
      setPage(prev => prev + 1);
    }
  }, [loading, hasMore]);

  const onRefresh = useCallback(() => {
    setPage(1);
    setHasMore(true);
    fetchOrders(1, true);
  }, [fetchOrders]);

  useEffect(() => {
    fetchOrders(page);
  }, [fetchOrders, page]);

  const renderFooter = () => {
    if (!loading || !hasMore) return null;
    
    return (
      <View style={styles.footer}>
        <ActivityIndicator size="small" color="#4E9F3D" />
      </View>
    );
  };

  const getStatusColor = (status) => {
    return statusColors[status] || statusColors['default'];
  };


  const renderOrderItem = ({ item }) => (
    <TouchableOpacity style={[
      styles.orderItem,
      { backgroundColor: getStatusColor(item.status) }
    ]}
    onPress={() => navigation.navigate('AdminOrderDetail', { order: item })} >
      <View style={styles.orderHeader}>
        <View style={styles.orderInfo}>
          <Text style={styles.orderNumber}>Заказ №{item.number}</Text>
          <Text style={styles.orderDate}>
            {new Date(item.created_at).toLocaleDateString('ru-RU', {
              day: 'numeric',
              month: 'short',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            })}
          </Text>
          {/* Показываем подразделение, если storeId администратора не задан */}
          {!authStore.admin?.storeId && item.store_name && (
            <View style={styles.storeRow}>
              <Icon name="store" size={16} color="#555" />
              <Text style={styles.storeText}>{item.store_name}</Text>
            </View>
          )}
          {item.client && (
            <View style={styles.clientRow}>
              <Icon name="person" size={16} color="#555" />
              <Text style={styles.clientText}>
                {item.client} {item.client.phone && `• ${item.client.phone}`}
              </Text>
            </View>
          )}
        </View>
        <View style={styles.orderDetails}>
          <Text style={styles.paymentText}>
            {item.payment_method}
          </Text>
          <Text style={styles.orderStatus}>{item.status}</Text>
          <Text style={styles.orderPrice}>{item.total_amount} ₽</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  if (!authStore.isAdmin) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center' }]}>
        <Icon name="admin-panel-settings" size={50} color="#FF3B30" />
        <Text style={styles.errorText}>Доступ запрещён</Text>
      </View>
    );
  }

  if (loading && !refreshing && orders.length === 0) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center' }]}>
        <ActivityIndicator size="large" color="#4E9F3D" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center' }]}>
        <Icon name="error-outline" size={50} color="#FF3B30" />
        <Text style={styles.errorText}>Ошибка загрузки</Text>
        <TouchableOpacity 
          style={styles.retryButton}
          onPress={onRefresh}
        >
          <Text style={styles.retryButtonText}>Повторить попытку</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <CustomHeader 
        title="Заказы"
        statusBarProps={{
          barStyle: 'light-content',
          backgroundColor: '#fff'
        }}
        safeAreaStyle={{
          backgroundColor: '#fff'
        }}
        headerStyle={{
          backgroundColor: '#fff',
          borderBottomWidth: 0
        }}
        iconColor="#000"
        titleStyle={{ color: '#000' }}
      />
      <FlatList
        data={orders}
        renderItem={renderOrderItem}
        keyExtractor={item => `${item.id}_${item.updated_at || item.created_at}`}
        contentContainerStyle={styles.listContent}
        onEndReached={loadMore}
        onEndReachedThreshold={0.2}
        ListFooterComponent={renderFooter}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#4E9F3D']}
            tintColor="#4E9F3D"
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Icon name="shopping-bag" size={50} color="#CCCCCC" />
            <Text style={styles.emptyText}>Нет заказов</Text>
          </View>
        }
      />
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  listContent: {
    padding: 8,
  },
  orderItem: {
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  orderInfo: {
    flex: 1,
  },
  orderDetails: {
    alignItems: 'flex-end',
    marginLeft: 10,
  },
  orderNumber: {
    fontSize: 15,
    fontWeight: '600',
    color: '#333',
  },
  orderDate: {
    fontSize: 13,
    color: '#555',
    marginTop: 2,
  },
  clientRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
  },
  clientText: {
    fontSize: 13,
    color: '#555',
    marginLeft: 4,
  },
  paymentText: {
    fontSize: 13,
    color: '#555',
    marginBottom: 4,
  },
  orderStatus: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
    marginBottom: 4,
  },
  orderPrice: {
    fontSize: 15,
    fontWeight: '700',
    color: '#333',
  },
  errorText: {
    fontSize: 16,
    color: '#FF3B30',
    marginTop: 16,
  },
  retryButton: {
    backgroundColor: '#4E9F3D',
    padding: 12,
    borderRadius: 8,
    marginTop: 20,
  },
  retryButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    marginTop: 16,
  },
  footer: {
    padding: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  storeRow: {
  flexDirection: 'row',
  alignItems: 'center',
  marginTop: 6,
},
storeText: {
  fontSize: 13,
  color: '#555',
  marginLeft: 4,
},
});

export default AdminOrdersScreen;
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  StyleSheet, 
  Image, 
  TouchableOpacity, 
  Dimensions,
  ActivityIndicator,
  FlatList,
  Share,
  Linking,
  Alert
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useSharedValue } from "react-native-reanimated";
import { useRoute, useNavigation } from '@react-navigation/native';
import { observer } from 'mobx-react-lite';
import { useStores } from '../useStores';
import CustomHeader from "../components/CustomHeader";
import ShareHelper from '../components/Share';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Carousel, {
  ICarouselInstance,
  Pagination,
} from "react-native-reanimated-carousel";
import MapView, { Marker } from 'react-native-maps';
import { useBottomTabBarHeight } from '@react-navigation/bottom-tabs';

const ProductScreen = observer(() => {
  const DEFAULT_IMAGE = 'https://api.koleso.app/public/img/no-image.jpg';
  const route = useRoute();
  const navigation = useNavigation();
 const { productId, fromCart } = route.params; // Получаем флаг fromCart
  const { cartStore, authStore, favoritesStore } = useStores();
  const [localFavorites, setLocalFavorites] = useState({});

    const insets = useSafeAreaInsets();
    const statusBarHeight = insets.top;


   const handleBackPress = () => {
    if (fromCart) {
      navigation.navigate('Cart');
    } else {
      navigation.goBack();
    }
  };

  const tabBarHeight = useBottomTabBarHeight();

  
  // Все хуки должны вызываться в одном и том же порядке при каждом рендере
  const [product, setProduct] = useState(null);
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeSlide, setActiveSlide] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addingToCart, setAddingToCart] = useState(false);
  const [selectedStore, setSelectedStore] = useState(null);
  const mapRef = useRef(null);


  const handleShare = async () => {
    await ShareHelper.shareDeepLink(`product/${productId}`, {
      source: 'share',
      campaign: 'social',
    });
  };

  useEffect(() => {
    if (selectedStore && mapRef.current) {
      const region = {
        latitude: parseFloat(selectedStore.storeInfo.latitude),
        longitude: parseFloat(selectedStore.storeInfo.longitude),
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      };
      mapRef.current.animateToRegion(region, 500);
    }
  }, [selectedStore]);

  const isFavorite = useCallback((productId) => {
    if (localFavorites.hasOwnProperty(productId)) {
      return localFavorites[productId];
    }
    return favoritesStore.items.some(item => item.product_id == productId);
  }, [localFavorites, favoritesStore.items]);

  useEffect(() => {
      const unsubscribe = navigation.addListener('focus', () => {
        favoritesStore.refreshFavorites(authStore.token);
        setLocalFavorites(favoritesStore.items);
      });
    
      return unsubscribe;
    }, [navigation]);

  const toggleFavorite = useCallback(async () => {
    if (!product) return;
    
    const productId = product.id;
    const newValue = !isFavorite(productId);
    
    // Оптимистичное обновление
    setLocalFavorites(prev => ({ ...prev, [productId]: newValue }));
    
    try {
      if (newValue) {
        await favoritesStore.addToFavorites(product, authStore.token);
      } else {
        await favoritesStore.removeFromFavorites(productId, authStore.token);
      }
    } catch (error) {
      // Откатываем при ошибке
      setLocalFavorites(prev => ({ ...prev, [productId]: !newValue }));
    }
  }, [product, isFavorite, authStore.token]);


  const formatValue = (value) => {
    let num;
  
    // Пытаемся преобразовать в число
    if (typeof value === 'string') {
      num = Number(value.trim());
    } else if (typeof value === 'number') {
      num = value;
    } else {
      return value; // Не число — возвращаем как есть
    }
  
    // Проверяем, действительно ли получилось число
    if (isNaN(num)) {
      return value;
    }
  
    // Округляем до 2 знаков и превращаем в строку
    const formatted = num.toFixed(2);
  
    // Убираем лишние нули после точки
    return parseFloat(formatted).toString();
  };
  
  const width = Dimensions.get("window").width;
  const ref = useRef(null);
  const animatedIndex = useSharedValue(0); // Выносим useSharedValue в начало


    // Добавляем обработчик для кнопки "Назад" в заголовке
  useEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <TouchableOpacity 
          onPress={() => {
            if (fromCart) {
              navigation.navigate('Cart');
            } else {
              navigation.goBack();
            }
          }}
          style={{ padding: 10 }}
        >
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
      )
    });
  }, [navigation, fromCart]);

  // Загрузка данных товара и магазинов
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Загрузка товара
        const productResponse = await fetch(`https://api.koleso.app/api/product.php?id=${productId}`);
        if (!productResponse.ok) throw new Error(`HTTP error! status: ${productResponse.status}`);
        const productData = await productResponse.json();
        if (!productData.success) throw new Error(productData.error || 'Failed to load product');
        
        // Загрузка магазинов
        const storesResponse = await fetch('https://api.koleso.app/api/stores_products.php', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${authStore.token}`,
            'Content-Type': 'application/json'
          }
        });
        if (!storesResponse.ok) throw new Error(`HTTP error! status: ${storesResponse.status}`);
        const storesData = await storesResponse.json();
        
        // Объединение данных о наличии с информацией о магазинах
        const enrichedStocks = productData.product.stocks.map(stock => {
          // Ищем магазин по ID из stock.store_id
          const storeInfo = storesData.find(store => store.id === stock.store_id.toString());
          return {
            ...stock,
            storeInfo
          };
        }).filter(item => item.storeInfo); 


         // Специальная сортировка:
        // 1. Сначала магазины с наличием (кроме id 8)
        // 2. Затем магазин с id 8 (если есть)
        // 3. Затем магазины без наличия
        enrichedStocks.sort((a, b) => {
          const isA8 = a.store_id === 8;
          const isB8 = b.store_id === 8;
          
          // Если оба магазина с наличием или оба без
          if ((a.quantity > 0 && b.quantity > 0) || (a.quantity <= 0 && b.quantity <= 0)) {
            // Если один из них - магазин 8, он должен быть первым в своей группе
            if (isA8) return -1;
            if (isB8) return 1;
            return 0;
          }
          
          // Если у одного есть наличие, а у другого нет
          if (a.quantity > 0 && b.quantity <= 0) return -1;
          if (a.quantity <= 0 && b.quantity > 0) return 1;
          
          return 0;
        });

        // Ограничиваем количество до 20, если больше
        const limitedStocks = enrichedStocks.map(item => ({
          ...item,
          quantity: item.quantity > 20 ? 20 : item.quantity
        }));

        
        
        setProduct(productData.product);
        setStores(limitedStocks);
        
      } catch (err) {
        console.error('Failed to load data:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [productId, authStore.token]);

  // Обработчик изменения количества
  const handleQuantityChange = (value) => {
    const newValue = quantity + value;
    if (newValue >= 1 && newValue <= 10) {
      setQuantity(newValue);
    }
  };

  // Добавление товара в корзину
  const addToCart = async () => {
    if (!authStore.isLoggedIn) {
      Alert.alert(
        'Требуется авторизация',
        'Для добавления товаров в корзину необходимо войти в систему',
        [
          { text: 'Отмена', style: 'cancel' },
          { text: 'Войти', onPress: () => navigation.navigate('Auth') }
        ]
      );
      return;
    }

    try {
      setAddingToCart(true);
      await cartStore.addToCart({
        product_id: product.id,
        quantity,
        price: product.price,
        name: product.name,
        brand: product.brand,
        image_url: product.images[0]
      }, authStore.token);
       
      Alert.alert('Успешно', 'Товар добавлен в корзину', [
        { text: 'OK', onPress: () => {} },
        { 
          text: 'Перейти в корзину', 
          onPress: () => navigation.navigate('Cart')
        }
      ]);
    } catch (error) {
      Alert.alert('Ошибка', 'Не удалось добавить товар в корзину');
      console.error('Add to cart error:', error);
    } finally {
      setAddingToCart(false);
    }
  };


    // Добавление товара в корзину
    const FastBuyCart = async () => {
      if (!authStore.isLoggedIn) {
        Alert.alert(
          'Требуется авторизация',
          'Для добавления товаров в корзину необходимо войти в систему',
          [
            { text: 'Отмена', style: 'cancel' },
            { text: 'Войти', onPress: () => navigation.navigate('Auth') }
          ]
        );
        return;
      }
  
      try {
        setAddingToCart(true);
        await cartStore.addToCart({
          product_id: product.id,
          quantity,
          price: product.price,
          name: product.name,
          brand: product.brand,
          image_url: product.images[0]
        }, authStore.token);
         
      
      } catch (error) {
        Alert.alert('Ошибка', 'Не удалось добавить товар в корзину');
        console.error('Add to cart error:', error);
      } finally {
        setAddingToCart(false);
      }
    };

  // Открытие карты с магазинами
  const openStoreMap = (store) => {
    const { latitude, longitude, name } = store;
    const url = `https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}&query_place_id=${name}`;
    Linking.openURL(url);
  };

  // Рендер изображений в карусели
  const renderImage = ({ item }) => (
    <Image 
      source={{ uri: item || DEFAULT_IMAGE }} 
      style={styles.productImage} 
      resizeMode="contain"
    />
  );

  // Рендер магазинов с наличием
  const renderStoreItem = ({ item }) => {
    const isSelected = selectedStore?.store_id === item.store_id;
    return (
      <TouchableOpacity 
        style={[styles.storeItem, isSelected && styles.selectedStoreItem]}
        onPress={() => setSelectedStore(isSelected ? null : item)}
      >
        <Text style={styles.storeName}>{item.storeInfo.name}</Text>
        <Text style={[styles.storeStock, item.quantity > 0 ? styles.inStock : styles.outOfStock]}>
          {item.quantity > 0 ? `✓ В наличии: ${item.quantity} шт.` : '✗ Нет в наличии'}
        </Text>
        <Text style={styles.storeAddress} numberOfLines={1}>
          {item.storeInfo.city}, {item.storeInfo.address}
        </Text>
        <TouchableOpacity 
          style={styles.mapButton}
          onPress={() => openStoreMap(item.storeInfo)}
        >
          <Icon name="map" size={16} color="#006363" />
          <Text style={styles.mapButtonText}>На карте</Text>
        </TouchableOpacity>
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#006363" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Icon name="error-outline" size={50} color="#FF6B6B" />
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity 
          style={styles.retryButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.retryButtonText}>Вернуться назад</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!product) {
    return (
      <View style={styles.errorContainer}>
        <Icon name="remove-shopping-cart" size={50} color="#FF6B6B" />
        <Text style={styles.errorText}>Товар не найден</Text>
        <TouchableOpacity 
          style={styles.retryButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.retryButtonText}>Вернуться назад</Text>
        </TouchableOpacity>
      </View>
    );
  }



  return (<View style={[styles.container, { paddingTop: statusBarHeight }]}>
     <CustomHeader 
        title=""
        navigation={navigation}
        statusBarProps={{
          barStyle: 'light-content',
          backgroundColor: '#FFF'
        }}
        safeAreaStyle={{
          backgroundColor: '#FFF'
        }}
        headerStyle={{
          backgroundColor: '#FFF',
          borderBottomWidth: 0
        }}
        rightAction={() => toggleFavorite()}
        //onBackPress={() => setShowModelModal(false)}
        rightIcon = {isFavorite(productId) ? "heart" : "heart-outline"}
        rightIcon2="share-outline" // пример второй иконки
        rightAction2={() => handleShare()} // обработчик для второй иконки
        iconColorRight2="#000"              
          
     
        iconColorRight={isFavorite(productId) ? "#FF3B30" : "#000"}
        titleStyle={{ color: '#000' }}
        withBackButton/>
     
     

      <ScrollView 
        contentContainerStyle={[styles.content, { paddingBottom: tabBarHeight }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Карусель изображений */}
        <View style={styles.carouselContainer}>
          <Carousel
            ref={ref}
            data={product.images?.length ? product.images : [DEFAULT_IMAGE]}
            renderItem={renderImage}
            height={width / 1.5}
            width={width}
            onSnapToItem={(index) => {
              setActiveSlide(index);
              animatedIndex.value = index;
            }}
          />
         
        </View>


        {/* Основная информация */}
        <View style={styles.infoSection}>
          <Text style={styles.productBrand}>{product.brand}</Text>
          <Text style={styles.productName}>{product.name}</Text>
          
          <View style={styles.priceContainer}>
            <Text style={styles.productPrice}>{parseFloat(product.price).toFixed(0)} ₽</Text>
            {6000 && 6000 > product.price && (
              <Text style={styles.productOldPrice}>{parseFloat(product.price)} ₽</Text>
            )}
          </View>
        </View>

        {/* Кнопки действий */}
        <View style={styles.actionButtons}>
          <View style={styles.quantitySelector}>
            <TouchableOpacity 
              style={styles.quantityButton}
              onPress={() => handleQuantityChange(-1)}
              disabled={quantity <= 1}
            >
              <Icon name="remove" size={20} color={quantity <= 1 ? "#CCCCCC" : "#006363"} />
            </TouchableOpacity>
            <Text style={styles.quantityText}>{quantity}</Text>
            <TouchableOpacity 
              style={styles.quantityButton}
              onPress={() => handleQuantityChange(1)}
              disabled={quantity >= 10}
            >
              <Icon name="add" size={20} color={quantity >= 10 ? "#CCCCCC" : "#006363"} />
            </TouchableOpacity>
          </View>
          
          <TouchableOpacity 
            style={styles.buyButton}
            onPress={() => {
              FastBuyCart();
              navigation.navigate('Cart');
            }}
            disabled={addingToCart}
          >
            {addingToCart ? (
              <ActivityIndicator size="small" color="#FFF" />
            ) : (
              <Text style={styles.buyButtonText}>Купить</Text>
            )}
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.cartButton}
            onPress={addToCart}
            disabled={addingToCart}
          >
            {addingToCart ? (
              <ActivityIndicator size="small" color="#006363" />
            ) : (
              <Icon name="shopping-cart" size={20} color="#006363" />
            )}
          </TouchableOpacity>
        </View>

        {/* Наличие в магазинах */}
        <View style={styles.storesSection}>
          <View style={styles.sectionHeader}>
            <Icon name="store" size={20} color="#006363" />
            <Text style={styles.sectionTitle}>Наличие в магазинах</Text>
          </View>
          
          {stores.length > 0 ? (
            <>
              <FlatList
                data={stores}
                renderItem={renderStoreItem}
                keyExtractor={(item) => item.store_id.toString()}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.storesList}
              />
              
              {selectedStore && (
                <View style={styles.storeDetails}>
                  <View style={styles.storeInfo}>
                    <Text style={styles.storeDetailName}>{selectedStore.storeInfo.name}</Text>
                    <Text style={styles.storeDetailAddress}>
                      {selectedStore.storeInfo.city}, {selectedStore.storeInfo.address}
                    </Text>
                    <Text style={styles.storeDetailHours}>
                      {selectedStore.storeInfo.working_hours || 'Часы работы не указаны'}
                    </Text>
                    <Text style={styles.storeDetailPhone}>
                      {selectedStore.storeInfo.phone || 'Телефон не указан'}
                    </Text>
                  </View>
                  
                  <View style={styles.mapContainer}>
                  <MapView
  ref={mapRef}
  style={styles.map}
  initialRegion={{
    latitude: parseFloat(selectedStore.storeInfo.latitude),
    longitude: parseFloat(selectedStore.storeInfo.longitude),
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  }}
>
  <Marker
    coordinate={{
      latitude: parseFloat(selectedStore.storeInfo.latitude),
      longitude: parseFloat(selectedStore.storeInfo.longitude),
    }}
    title={selectedStore.storeInfo.name}
    description={selectedStore.storeInfo.address}
  />
</MapView>
                  </View>
                </View>
              )}
            </>
          ) : (
            <Text style={styles.noStoresText}>Нет информации о наличии в магазинах</Text>
          )}
        </View>

        {/* Характеристики */}
        <View style={styles.specsSection}>
          <View style={styles.sectionHeader}>
            <Icon name="list-alt" size={20} color="#006363" />
            <Text style={styles.sectionTitle}>Характеристики</Text>
          </View>
          
          <View style={styles.specsGrid}>
            {product.category === 'Автошины' && (
              <>
                <SpecItem title="Ширина" value={formatValue(product.width)} />
                <SpecItem title="Профиль" value={formatValue(product.profile)} />
                <SpecItem title="Диаметр" value={formatValue(product.diameter)} />
                <SpecItem title="Сезон" value={product.season} />
                <SpecItem title="Шипы" value={product.spiked ? 'Да' : 'Нет'} />
                <SpecItem title="RunFlat" value={product.runflat ? 'Да' : 'Нет'} />
                <SpecItem title="Индекс нагрузки" value={product.load_index} />
                <SpecItem title="Индекс скорости" value={product.speed_index} />
              </>
            )}
            
            {product.category === 'Диски' && (
              <>
                <SpecItem title="Тип диска" value={product.rim_type} />
                <SpecItem title="Диаметр" value={formatValue(product.diameter)} />
                <SpecItem title="PCD" value={formatValue(product.pcd)} />
                <SpecItem title="Вылет (ET)" value={formatValue(product.et)} />
                <SpecItem title="DIA" value={formatValue(product.dia)} />
                <SpecItem title="Цвет" value={product.rim_color} />
                <SpecItem title="Количество отверстий" value={product.hole} />
              </>
            )}
            
            {product.category === 'Аккумуляторы' && (
              <>
                <SpecItem title="Емкость" value={product.capacity} />
                <SpecItem title="Полярность" value={product.polarity} />
                <SpecItem title="Пусковой ток" value={product.starting_current} />
              </>
            )}
          </View>
        </View>

        {/* Описание */}
        {product.description && (
          <View style={styles.descriptionSection}>
            <View style={styles.sectionHeader}>
              <Icon name="description" size={20} color="#006363" />
              <Text style={styles.sectionTitle}>Описание</Text>
            </View>
            <Text style={styles.descriptionText}>{product.description}</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
});

// Компонент для отображения характеристик
const SpecItem = ({ title, value }) => (
  <View style={styles.specItem}>
    <Text style={styles.specTitle}>{title}</Text>
    <Text style={styles.specValue}>{value || '—'}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    elevation: 2,
  },
  backButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  headerRight: {
    width: 32,
  },
  content: {
    paddingBottom: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#F8F9FA',
  },
  errorText: {
    color: '#FF6B6B',
    fontSize: 16,
    marginTop: 10,
    marginBottom: 20,
    textAlign: 'center',
  },
  retryButton: {
    backgroundColor: '#006363',
    padding: 12,
    borderRadius: 6,
    minWidth: 150,
    alignItems: 'center',
  },
  retryButtonText: {
    color: '#FFF',
    fontWeight: '600',
  },
  carouselContainer: {
    backgroundColor: '#FFF',
    marginBottom: 8,
  },
  productImage: {
    width: '100%',
    height: '100%',
  },
  paginationContainer: {
    position: 'absolute',
    bottom: 10,
    alignSelf: 'center',
  },
  paginationDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.5)',
    marginHorizontal: 4,
  },
  paginationDotActive: {
    backgroundColor: '#006363',
  },
  infoSection: {
    backgroundColor: '#FFF',
    padding: 16,
    marginBottom: 8,
    borderRadius: 8,
    marginHorizontal: 16,
    elevation: 1,
  },
  productBrand: {
    fontSize: 16,
    color: '#666',
    marginBottom: 4,
  },
  productName: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  productPrice: {
    fontSize: 22,
    fontWeight: '700',
    color: '#006363',
    marginRight: 12,
  },
  productOldPrice: {
    fontSize: 16,
    color: '#999',
    textDecorationLine: 'line-through',
  },
  actionButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#FFF',
    marginBottom: 8,
    borderRadius: 8,
    marginHorizontal: 16,
    elevation: 1,
  },
  quantitySelector: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 6,
    marginRight: 12,
  },
  quantityButton: {
    padding: 10,
  },
  quantityText: {
    fontSize: 16,
    fontWeight: '600',
    paddingHorizontal: 12,
    color: '#333',
  },
  buyButton: {
    flex: 1,
    backgroundColor: '#006363',
    paddingVertical: 12,
    borderRadius: 6,
    alignItems: 'center',
    marginRight: 12,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  buyButtonText: {
    color: '#FFF',
    fontWeight: '600',
    fontSize: 16,
  },
  cartButton: {
    padding: 12,
    borderWidth: 1,
    borderColor: '#006363',
    borderRadius: 6,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginLeft: 8,
  },
  specsSection: {
    backgroundColor: '#FFF',
    padding: 16,
    marginBottom: 8,
    borderRadius: 8,
    marginHorizontal: 16,
    elevation: 1,
  },
  specsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  specItem: {
    width: '48%',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  specTitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  specValue: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  storesSection: {
    backgroundColor: '#FFF',
    padding: 16,
    marginBottom: 8,
    borderRadius: 8,
    marginHorizontal: 16,
    elevation: 1,
  },
  storesList: {
    paddingBottom: 8,
  },
  storeItem: {
    width: 190,
    padding: 12,
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    backgroundColor: '#FFF',
  },
  selectedStoreItem: {
    borderColor: '#006363',
    backgroundColor: '#f0feff',
  },
  storeName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 6,
  },
  storeStock: {
    fontSize: 13,
    fontWeight: '500',
    marginBottom: 6,
  },
  inStock: {
    color: '#4CAF50',
  },
  outOfStock: {
    color: '#F44336',
  },
  storeAddress: {
    fontSize: 12,
    color: '#666',
    marginBottom: 8,
  },
  mapButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 6,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    marginTop: 4,
  },
  mapButtonText: {
    color: '#006363',
    fontSize: 12,
    fontWeight: '500',
    marginLeft: 4,
  },
  noStoresText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    paddingVertical: 12,
  },
  storeDetails: {
    marginTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    paddingTop: 12,
  },
  storeInfo: {
    marginBottom: 12,
  },
  storeDetailName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  storeDetailAddress: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  storeDetailHours: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  storeDetailPhone: {
    fontSize: 14,
    color: '#006363',
    fontWeight: '500',
  },
  mapContainer: {
    height: 180,
    borderRadius: 8,
    overflow: 'hidden',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  descriptionSection: {
    backgroundColor: '#FFF',
    padding: 16,
    marginBottom: 8,
    borderRadius: 8,
    marginHorizontal: 16,
    elevation: 1,
  },
  descriptionText: {
    fontSize: 14,
    color: '#333',
    lineHeight: 20,
  },
});

export default ProductScreen;
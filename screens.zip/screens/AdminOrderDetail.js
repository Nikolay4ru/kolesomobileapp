import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  ActivityIndicator,
  Image,
  Dimensions,
  Alert
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useStores } from "../useStores";

const { width } = Dimensions.get('window');

const AdminOrderDetailScreen = () => {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const route = useRoute();
  const { authStore } = useStores();
  const { order } = route.params;
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleAction = async (action) => {
    try {
      setLoading(true);
      
      // Проверка наличия товара перед резервированием
      if (action === 'reserve') {
        const insufficientItems = order.items.filter(item => item.quantity > item.stock);
        if (insufficientItems.length > 0) {
          const itemNames = insufficientItems.map(item => item.name).join(', ');
          Alert.alert(
            'Недостаточно товара на складе',
            `Следующих товаров недостаточно для резервирования: ${itemNames}`,
            [{ text: 'OK' }]
          );
          return;
        }
      }

      const response = await fetch('https://api.koleso.app/api/ordersAction.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authStore.token}`
        },
        body: JSON.stringify({
          order_id: order.id,
          action: action
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || 'Ошибка выполнения действия');
      }
      
      navigation.goBack();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = () => {
    switch(order.status) {
      case 'Отменён (Удален)': return '#FF3B30';
      case 'Отменён (Возврат товара)': return '#FF3B30';
      case 'Завершен': return '#4CAF50';
      case 'Новый': return '#FFEE58';
      case 'Товар зарезервирован': return '#B3C1FD';
      case 'В обработке': return '#FF9800';
      default: return '#9E9E9E';
    }
  };


  const renderStockInfo = (quantity, stock) => {
    const isInsufficient = quantity > stock;
    return (
      <Text style={[styles.stockText, isInsufficient && styles.insufficientStock]}>
        {stock} шт. на складе {isInsufficient && '⚠️'}
      </Text>
    );
  };



  return (
    <SafeAreaView edges={['top', 'left', 'right']} style={styles.container}>
        <View style={styles.header}>
        <TouchableOpacity 
          onPress={() => navigation.goBack()}
          style={styles.backButton}
        >
          <Icon name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.title}>Заказ #{order.number}</Text>
        <View style={{ width: 24 }} />
      </View>
      <View style={[styles.statusContainer, { backgroundColor: getStatusColor() }]}>
        <Text style={styles.statusText}>{order.status}</Text>
      </View>
    <ScrollView 
      style={[styles.container, {  }]}
      contentContainerStyle={styles.contentContainer}
    >
    

      <View style={styles.card}>
        <View style={styles.sectionHeader}>
          <Icon name="receipt" size={20} color="#666" />
          <Text style={styles.sectionTitle}>Информация о заказе</Text>
        </View>
        
        <View style={styles.infoContainer}>
          <View style={styles.infoRow}>
            <Icon name="calendar-today" size={16} color="#666" style={styles.infoIcon} />
            <Text style={styles.infoLabel}>Дата:</Text>
            <Text style={styles.infoValue}>{order.created_at}</Text>
          </View>
          <View style={styles.infoRow}>
            <Icon name="store" size={16} color="#666" style={styles.infoIcon} />
            <Text style={styles.infoLabel}>Магазин:</Text>
            <Text style={styles.infoValue}>{order.store_name}</Text>
          </View>

          <View style={styles.infoRow}>
            <Icon name="person" size={16} color="#666" style={styles.infoIcon} />
            <Text style={styles.infoLabel}>Клиент:</Text>
            <Text style={styles.infoValue}>{order.client}</Text>
          </View>
          <View style={styles.infoRow}>
            <Icon name="phone" size={16} color="#666" style={styles.infoIcon} />
            <Text style={styles.infoLabel}>Телефон:</Text>
            <Text style={styles.infoValue}>{order.client_phone}</Text>
          </View>
          <View style={styles.infoRow}>
            <Icon name="attach-money" size={16} color="#666" style={styles.infoIcon} />
            <Text style={styles.infoLabel}>Сумма:</Text>
            <Text style={[styles.infoValue, styles.amountValue]}>{order.total_amount} ₽</Text>
          </View>
        </View>
      </View>

      <View style={styles.card}>
        <View style={styles.sectionHeader}>
          <Icon name="shopping-basket" size={20} color="#666" />
          <Text style={styles.sectionTitle}>Товары ({order.items.length})</Text>
        </View>
        
        {order.items.map((item, index) => (
          <TouchableOpacity  key={index} style={styles.productItem} onPress={() => navigation.navigate('Cart', {
      screen: 'ProductModal',
      params: {
        productId: item.product_id,
        fromCart: false
      }
    })}
  >
        
            {item.image_url && (
              <Image 
                source={{ uri: item.image_url }} 
                style={styles.productImage}
                resizeMode="contain"
              />
            )}
            <View style={styles.productInfo}>
              <Text style={styles.productName} numberOfLines={2}>{item.name}</Text>
              {renderStockInfo(item.quantity, item.stock)}
              <View style={styles.productMeta}>
                <Text style={styles.productQuantity}>{item.quantity} шт.</Text>
                <Text style={styles.productPrice}>{item.price.toLocaleString('ru-RU')} ₽</Text>
              </View>
              <Text style={styles.productTotal}>
                Итого: {(item.price * item.quantity).toLocaleString('ru-RU')} ₽
              </Text>
            </View>
           </TouchableOpacity>
        ))}
      </View>

      <View style={styles.actionsContainer}>
        {order.status === 'Новый' && (
          <>
            <TouchableOpacity 
              style={[styles.actionButton, styles.reserveButton]}
              onPress={() => handleAction('reserve')}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Icon name="inventory" size={20} color="#fff" style={styles.buttonIcon} />
                  <Text style={styles.actionButtonText}>Зарезервировать</Text>
                </>
              )}
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={[styles.actionButton, styles.invoiceButton]}
              onPress={() => handleAction('invoice')}
              disabled={true}
            >
              <Icon name="description" size={20} color="#fff" style={styles.buttonIcon} />
              <Text style={styles.actionButtonText}>Выставить счет</Text>
            </TouchableOpacity>
          </>
        )}
        
        {order.status !== 'Отменён (Возврат товара)' && order.status !== 'Отменён (Удален)' && (
          <TouchableOpacity 
            style={[styles.actionButton, styles.cancelButton]}
            onPress={() => handleAction('cancel')}
            disabled={loading}
          >
             {loading ? (
                <ActivityIndicator color="#FF3B30" />
              ) : (
            <>
            <Icon name="cancel" size={20} color="#FF3B30" style={styles.buttonIcon} />
            <Text style={[styles.actionButtonText, styles.cancelButtonText]}>Отменить заказ</Text>
             </>
              )}
          </TouchableOpacity>
        )}
      </View>

      {error && (
        <View style={styles.errorContainer}>
          <Icon name="error-outline" size={20} color="#FF3B30" />
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}
    </ScrollView>
    <SafeAreaView edges={['bottom']} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
contentContainer: {
  paddingBottom: 80, // Увеличьте это значение по необходимости
  paddingHorizontal: 0,
  },
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  backButton: {
    padding: 4,
    borderRadius: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
  },
  statusContainer: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    backgroundColor: '#2196F3',
  },
  statusText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    margin: 16,
    marginBottom: 0,
    padding: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginLeft: 8,
  },
  infoContainer: {
    padding: 16,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 14,
  },
  infoIcon: {
    marginRight: 8,
    width: 20,
    textAlign: 'center',
  },
  infoLabel: {
    fontSize: 14,
    color: '#666',
    width: 80,
    marginRight: 8,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
    flex: 1,
    textAlign: 'right',
  },
  amountValue: {
    fontWeight: '600',
    color: '#4CAF50',
    fontSize: 15,
  },
  productItem: {
    flexDirection: 'row',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f5f5f5',
  },
  productImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
    backgroundColor: '#f9f9f9',
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 14,
    color: '#333',
    marginBottom: 6,
  },
  stockText: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  insufficientStock: {
    color: '#FF3B30',
    fontWeight: '500',
  },
  productMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  productQuantity: {
    fontSize: 13,
    color: '#666',
  },
  productPrice: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  productTotal: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginTop: 4,
  },
  actionsContainer: {
    paddingHorizontal: 16,
    marginTop: 20,
  },
  actionButton: {
    borderRadius: 10,
    paddingVertical: 14,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  reserveButton: {
    backgroundColor: '#4CAF50',
  },
  invoiceButton: {
    backgroundColor: '#2196F3',
  },
  cancelButton: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#FF3B30',
  },
  buttonIcon: {
    marginRight: 8,
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  cancelButtonText: {
    color: '#FF3B30',
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    marginTop: 10,
    backgroundColor: '#FFEBEE',
    borderRadius: 8,
    marginHorizontal: 16,
  },
  errorText: {
    color: '#FF3B30',
    fontSize: 14,
    marginLeft: 8,
  },
});

export default AdminOrderDetailScreen;
import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';

const StorageDetailScreen = () => {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const route = useRoute();
  const { storage } = route.params;

  const formatDate = (dateString) => {
    if (!dateString) return 'не указана';
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU');
  };

  const handleCreateIssueRequest = () => {
    navigation.navigate('CreateIssueRequest', { storageId: storage.id });
  };

  return (
    <ScrollView 
      style={[styles.container, { paddingTop: insets.top }]}
      contentContainerStyle={styles.contentContainer}
    >
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Icon name="arrow-back" size={24} color="#4E9F3D" />
        </TouchableOpacity>
        <Text style={styles.title}>Договор хранения</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.card}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Основная информация</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Номер договора:</Text>
            <Text style={styles.infoValue}>{storage.contract_number}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Статус:</Text>
            <View style={[
              styles.statusBadge,
              storage.status === 'cancelled' && styles.statusCancelled,
              storage.status === 'completed' && styles.statusCompleted
            ]}>
              <Text style={styles.statusText}>
                {storage.status === 'Хранение на складе' ? 'Хранение на складе' : 
                 storage.status === 'completed' ? 'Завершен' : 'Отменен'}
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Сроки хранения</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Дата начала:</Text>
            <Text style={styles.infoValue}>{formatDate(storage.start_date)}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Дата окончания:</Text>
            <Text style={styles.infoValue}>{formatDate(storage.end_date)}</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Хранимые товары</Text>
          <Text style={styles.nomenclature}>{storage.nomenclature}</Text>
        </View>

        {storage.description && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Дополнительная информация</Text>
            <Text style={styles.description}>{storage.description}</Text>
          </View>
        )}
      </View>

      <TouchableOpacity 
        style={styles.actionButton}
        onPress={handleCreateIssueRequest}
      >
        <Text style={styles.actionButtonText}>Заявка на выдачу</Text>
        <Icon name="chevron-right" size={20} color="#fff" />
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  contentContainer: {
    paddingBottom: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 8,
    margin: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  infoLabel: {
    fontSize: 14,
    color: '#666',
    flex: 1,
  },
  infoValue: {
    fontSize: 14,
    color: '#333',
    flex: 1,
    textAlign: 'right',
  },
  statusBadge: {
    backgroundColor: 'rgba(78, 159, 61, 0.1)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    color: '#4E9F3D',
    fontSize: 12,
    fontWeight: '500',
  },
  statusCancelled: {
    backgroundColor: 'rgba(255, 59, 48, 0.1)',
  },
  statusCompleted: {
    backgroundColor: 'rgba(0, 122, 255, 0.1)',
  },
  nomenclature: {
    fontSize: 14,
    color: '#333',
    lineHeight: 20,
  },
  description: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  actionButton: {
    backgroundColor: '#4E9F3D',
    borderRadius: 8,
    padding: 16,
    marginHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default StorageDetailScreen;
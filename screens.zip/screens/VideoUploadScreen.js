import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Alert, TextInput, FlatList, Modal, Animated } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import * as ImagePicker from 'react-native-image-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { observer } from "mobx-react-lite";
import axios from 'axios';
import { useStores } from "../useStores";

const VideoUploadScreen = observer(({ navigation }) => {
  const [uploading, setUploading] = useState(false);
  const { authStore } = useStores();
  const [progress, setProgress] = useState(0);
  const [video, setVideo] = useState(null);
  const [fileName, setFileName] = useState('');
  const [orders, setOrders] = useState([]);
  const [showOrdersModal, setShowOrdersModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [fadeAnim] = useState(new Animated.Value(0));
  const insets = useSafeAreaInsets();
  const statusBarHeight = insets.top;

  useEffect(() => {
    // Анимация появления
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 300,
      useNativeDriver: true,
    }).start();
  }, []);

  // Загрузка списка заказов
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.post(
          'https://api.koleso.app/api/ozon_orders.php',
          {
            store_id: authStore.admin?.storeId,
          },
          {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${authStore.token}`
            }
          }
        );
        setOrders(response.data.orders || []);
      } catch (error) {
        console.error('Error fetching orders:', error);
        Alert.alert('Ошибка', 'Не удалось загрузить список заказов');
      }
    };

    fetchOrders();
  }, []);

  const selectVideo = () => {
    const options = {
      mediaType: 'video',
      videoQuality: 'high',
    };

    ImagePicker.launchImageLibrary(options, (response) => {
      if (response.didCancel) {
        console.log('User cancelled video picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.assets && response.assets[0]) {
        const source = response.assets[0];
        setVideo(source);
      }
    });
  };

  const handleFileNameChange = (text) => {
    setFileName(text);
  };

  const selectOrder = (order) => {
    setSelectedOrder(order);
    setFileName(`${order.number_ozon}`);
    setShowOrdersModal(false);
  };

  const uploadVideo = async () => {
    if (!selectedOrder) {
      Alert.alert('Ошибка', 'Пожалуйста, выберите заказ');
      return;
    }

    if (!video?.uri) {
      Alert.alert('Ошибка', 'Пожалуйста, выберите видео файл');
      return;
    }

    if (!fileName.trim()) {
      Alert.alert('Ошибка', 'Пожалуйста, укажите название файла');
      return;
    }

    setUploading(true);
    setProgress(0);

    const fileExt = video.type?.split('/')[1] || 'mp4';
    const fullFileName = `${fileName.trim()}.${fileExt}`;

    const formData = new FormData();
    formData.append('video', {
      uri: video.uri,
      type: video.type || 'video/mp4',
      name: fullFileName,
    });
    formData.append('fileName', fileName.trim());
    formData.append('orderId', selectedOrder.number_ozon);

    try {
      const response = await axios.post('https://api.koleso.app/upload_video.php', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          setProgress(percentCompleted);
        },
      });

      Alert.alert('Успех', 'Видео успешно загружено');
      setVideo(null);
      setFileName('');
      setSelectedOrder(null);
    } catch (error) {
      console.error('Upload error:', error);
      Alert.alert('Ошибка', error.message || 'Не удалось загрузить видео');
    } finally {
      setUploading(false);
    }
  };

  const ProgressBar = ({ progress }) => (
    <View style={styles.progressBarContainer}>
      <View style={[styles.progressBarFill, { width: `${progress}%` }]} />
    </View>
  );

  return (
    <View style={[styles.container, { paddingTop: statusBarHeight }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Icon name="arrow-back" size={24} color="#1a1a1a" />
        </TouchableOpacity>
        <Text style={styles.title}>Загрузка видео</Text>
        <View style={{ width: 40 }} />
      </View>

      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        {uploading ? (
          <View style={styles.uploadingCard}>
            <View style={styles.uploadingIcon}>
              <ActivityIndicator size="large" color="#007AFF" />
            </View>
            <Text style={styles.uploadingTitle}>Загружаем видео...</Text>
            <Text style={styles.progressText}>{progress}%</Text>
            <ProgressBar progress={progress} />
          </View>
        ) : (
          <>
            {/* Выбор заказа */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Выберите заказ</Text>
              <TouchableOpacity 
                style={[styles.selectCard, selectedOrder && styles.selectCardSelected]}
                onPress={() => setShowOrdersModal(true)}
              >
                <View style={styles.selectCardContent}>
                  <Icon 
                    name={selectedOrder ? "check-circle" : "receipt"} 
                    size={24} 
                    color={selectedOrder ? "#007AFF" : "#8E8E93"} 
                  />
                  <View style={styles.selectCardText}>
                    <Text style={[styles.selectCardTitle, selectedOrder && styles.selectedText]}>
                      {selectedOrder ? `Заказ #${selectedOrder.number_ozon}` : 'Выберите заказ'}
                    </Text>
                    {!selectedOrder && (
                      <Text style={styles.selectCardSubtitle}>Нажмите для выбора</Text>
                    )}
                  </View>
                  <Icon name="chevron-right" size={24} color="#C7C7CC" />
                </View>
              </TouchableOpacity>
            </View>

            {selectedOrder && (
              <>
                {/* Выбор видео */}
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>Видеофайл</Text>
                  {video ? (
                    <View style={styles.fileSelectedCard}>
                      <View style={styles.fileIconContainer}>
                        <Icon name="videocam" size={24} color="#ffffff" />
                      </View>
                      <View style={styles.fileInfo}>
                        <Text style={styles.fileName}>
                          {video.fileName || video.uri.split('/').pop()}
                        </Text>
                        <Text style={styles.fileSize}>
                          {video.fileSize ? `${Math.round(video.fileSize / 1024 / 1024)} МБ` : 'Видеофайл'}
                        </Text>
                      </View>
                      <TouchableOpacity 
                        style={styles.changeButton}
                        onPress={selectVideo}
                      >
                        <Text style={styles.changeButtonText}>Изменить</Text>
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <TouchableOpacity 
                      style={styles.uploadCard} 
                      onPress={selectVideo}
                    >
                      <View style={styles.uploadIconContainer}>
                        <Icon name="cloud-upload" size={32} color="#007AFF" />
                      </View>
                      <Text style={styles.uploadCardTitle}>Выберите видео</Text>
                      <Text style={styles.uploadCardSubtitle}>
                        Поддерживаются форматы MP4, MOV, AVI
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>

                {/* Название файла */}
                {video && (
                  <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Название файла</Text>
                    <View style={styles.inputCard}>
                      <TextInput
                        style={styles.textInput}
                        value={fileName}
                        onChangeText={handleFileNameChange}
                        placeholder="Введите название файла"
                        placeholderTextColor="#C7C7CC"
                      />
                    </View>
                    
                    {fileName.trim() && (
                      <View style={styles.previewCard}>
                        <Icon name="info-outline" size={16} color="#8E8E93" />
                        <Text style={styles.previewText}>
                          Итоговое имя: {fileName.trim()}.{video.type?.split('/')[1] || 'mp4'}
                        </Text>
                      </View>
                    )}

                    <TouchableOpacity 
                      style={[
                        styles.submitButton, 
                        !fileName.trim() && styles.submitButtonDisabled
                      ]} 
                      onPress={uploadVideo}
                      disabled={!fileName.trim()}
                    >
                      <Icon name="cloud-upload" size={20} color="#ffffff" />
                      <Text style={styles.submitButtonText}>Загрузить видео</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </>
            )}
          </>
        )}
      </Animated.View>

      {/* Модальное окно выбора заказа */}
      <Modal
        visible={showOrdersModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowOrdersModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity 
              style={styles.modalCloseButton}
              onPress={() => setShowOrdersModal(false)}
            >
              <Icon name="close" size={24} color="#007AFF" />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Выберите заказ</Text>
            <View style={{ width: 40 }} />
          </View>
          
          <FlatList
            data={orders}
            keyExtractor={(item) => item.number_ozon.toString()}
            style={styles.ordersList}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => (
              <TouchableOpacity 
                style={styles.orderCard}
                onPress={() => selectOrder(item)}
              >
                <View style={styles.orderIconContainer}>
                  <Icon name="receipt" size={20} color="#007AFF" />
                </View>
                <View style={styles.orderInfo}>
                  <Text style={styles.orderNumber}>Отправление #{item.number_ozon}</Text>
                </View>
                <Icon name="chevron-right" size={20} color="#C7C7CC" />
              </TouchableOpacity>
            )}
            ListEmptyComponent={() => (
              <View style={styles.emptyState}>
                <Icon name="inbox" size={64} color="#C7C7CC" />
                <Text style={styles.emptyStateTitle}>Нет заказов</Text>
                <Text style={styles.emptyStateSubtitle}>
                  Отправления пока не найдены
                </Text>
              </View>
            )}
          />
        </View>
      </Modal>
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F7',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5EA',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
    backgroundColor: '#F2F2F7',
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1a1a1a',
    textAlign: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 24,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1a1a1a',
    marginBottom: 12,
  },
  selectCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  selectCardSelected: {
    borderWidth: 2,
    borderColor: '#007AFF',
  },
  selectCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectCardText: {
    flex: 1,
    marginLeft: 16,
  },
  selectCardTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#8E8E93',
  },
  selectedText: {
    color: '#007AFF',
  },
  selectCardSubtitle: {
    fontSize: 14,
    color: '#C7C7CC',
    marginTop: 2,
  },
  uploadCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 32,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 2,
    borderColor: '#E5E5EA',
    borderStyle: 'dashed',
  },
  uploadIconContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#F0F8FF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  uploadCardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1a1a1a',
    marginBottom: 8,
  },
  uploadCardSubtitle: {
    fontSize: 14,
    color: '#8E8E93',
    textAlign: 'center',
    lineHeight: 20,
  },
  fileSelectedCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  fileIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#007AFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  fileInfo: {
    flex: 1,
    marginLeft: 16,
  },
  fileName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1a1a1a',
  },
  fileSize: {
    fontSize: 14,
    color: '#8E8E93',
    marginTop: 2,
  },
  changeButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#F0F8FF',
    borderRadius: 20,
  },
  changeButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#007AFF',
  },
  inputCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  textInput: {
    fontSize: 16,
    color: '#1a1a1a',
    padding: 20,
  },
  previewCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0F8FF',
    padding: 12,
    borderRadius: 12,
    marginTop: 12,
  },
  previewText: {
    fontSize: 14,
    color: '#8E8E93',
    marginLeft: 8,
  },
  submitButton: {
    backgroundColor: '#007AFF',
    borderRadius: 16,
    paddingVertical: 18,
    paddingHorizontal: 24,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 24,
    shadowColor: '#007AFF',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  submitButtonDisabled: {
    backgroundColor: '#C7C7CC',
    shadowOpacity: 0,
    elevation: 0,
  },
  submitButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  uploadingCard: {
    backgroundColor: '#ffffff',
    borderRadius: 24,
    padding: 40,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 6,
    marginTop: 40,
  },
  uploadingIcon: {
    marginBottom: 24,
  },
  uploadingTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1a1a1a',
    marginBottom: 8,
  },
  progressText: {
    fontSize: 32,
    fontWeight: '700',
    color: '#007AFF',
    marginBottom: 24,
  },
  progressBarContainer: {
    width: '100%',
    height: 6,
    backgroundColor: '#E5E5EA',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#007AFF',
    borderRadius: 3,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#F2F2F7',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5EA',
  },
  modalCloseButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
    backgroundColor: '#F2F2F7',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1a1a1a',
  },
  ordersList: {
    flex: 1,
    paddingTop: 20,
  },
  orderCard: {
    backgroundColor: '#ffffff',
    marginHorizontal: 20,
    marginBottom: 12,
    padding: 20,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  orderIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F0F8FF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  orderInfo: {
    flex: 1,
    marginLeft: 16,
  },
  orderNumber: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1a1a1a',
  },
  emptyState: {
    alignItems: 'center',
    paddingTop: 80,
    paddingHorizontal: 40,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#8E8E93',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateSubtitle: {
    fontSize: 16,
    color: '#C7C7CC',
    textAlign: 'center',
    lineHeight: 22,
  },
});

export default VideoUploadScreen;
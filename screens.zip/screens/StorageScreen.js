import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { observer } from "mobx-react-lite";
import { useStores } from "../useStores";
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const StorageScreen = observer(({ navigation }) => {
  const { authStore, storagesStore } = useStores();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const insets = useSafeAreaInsets();

  useEffect(() => {
    const fetchStorages = async () => {
      try {
        setLoading(true);
        await storagesStore.loadStorages(authStore.token);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (authStore.isLoggedIn) {
      fetchStorages();
    }
  }, [authStore.isLoggedIn, authStore.token]);

  const renderStorageItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.storageItem}
      onPress={() => navigation.navigate('StorageDetail', { storage: item })}
    >
      <View style={styles.storageHeader}>
        <Text style={styles.contractNumber}>Договор №{item.contract_number}</Text>
        <Text style={[
          styles.storageStatus,
          item.status === 'cancelled' && styles.statusCancelled,
          item.status === 'Выдано' && styles.statusCompleted
        ]}>
          {item.status === 'Хранение на складе' ? 'Хранение на складе' : 
           item.status === 'Выдано' ? 'Завершен' : 'Отменен'}
        </Text>
      </View>
      
      <View style={styles.dateRow}>
        <Text style={styles.dateLabel}>Дата окончания:</Text>
        <Text style={styles.dateValue}>{new Date(item.end_date).toLocaleDateString('ru-RU')}</Text>
      </View>
      
      <View style={styles.nomenclatureContainer}>
        <Text style={styles.nomenclatureLabel}>Хранимые товары:</Text>
        <Text style={styles.nomenclatureValue} numberOfLines={1}>{item.nomenclature}</Text>
      </View>
    </TouchableOpacity>
  );

  if (!authStore.isLoggedIn) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center' }]}>
        <Icon name="error-outline" size={50} color="#4E9F3D" style={styles.authIcon} />
        <Text style={styles.authMessage}>Для просмотра хранений необходимо авторизоваться</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center' }]}>
        <ActivityIndicator size="large" color="#4E9F3D" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center' }]}>
        <Icon name="error-outline" size={50} color="#FF3B30" style={styles.errorIcon} />
        <Text style={styles.errorText}>Ошибка при загрузке хранений</Text>
        <Text style={styles.errorDetail}>{error}</Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <FlatList
        data={storagesStore.storages}
        renderItem={renderStorageItem}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Icon name="warehouse" size={50} color="#CCCCCC" style={styles.emptyIcon} />
            <Text style={styles.emptyText}>У вас нет активных хранений</Text>
          </View>
        }
      />
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  listContent: {
    padding: 16,
  },
  storageItem: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  storageHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  contractNumber: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  storageStatus: {
    fontSize: 14,
    color: '#4E9F3D',
    fontWeight: '500',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(78, 159, 61, 0.1)',
  },
  statusCancelled: {
    color: '#FF3B30',
    backgroundColor: 'rgba(255, 59, 48, 0.1)',
  },
  statusCompleted: {
    color: '#007AFF',
    backgroundColor: 'rgba(0, 122, 255, 0.1)',
  },
  dateRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  dateLabel: {
    fontSize: 14,
    color: '#666',
  },
  dateValue: {
    fontSize: 14,
    color: '#333',
  },
  nomenclatureContainer: {
    marginTop: 8,
  },
  nomenclatureLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  nomenclatureValue: {
    fontSize: 14,
    color: '#333',
    lineHeight: 20,
  },
  authMessage: {
    fontSize: 16,
    textAlign: 'center',
    margin: 20,
    color: '#666',
    maxWidth: '80%',
  },
  errorText: {
    fontSize: 16,
    textAlign: 'center',
    margin: 20,
    color: '#FF3B30',
    maxWidth: '80%',
  },
  errorDetail: {
    fontSize: 14,
    textAlign: 'center',
    marginHorizontal: 20,
    color: '#666',
    maxWidth: '80%',
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 16,
    color: '#666',
  },
  authIcon: {
    marginBottom: 16,
  },
  errorIcon: {
    marginBottom: 16,
  },
  emptyIcon: {
    marginBottom: 16,
    opacity: 0.5,
  },
});

export default StorageScreen;
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { observer } from "mobx-react-lite";
import { useStores } from "../useStores";
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const OrdersScreen = observer(({ navigation }) => {
  const { authStore, ordersStore } = useStores();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const insets = useSafeAreaInsets();

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true);
        await ordersStore.loadOrders(authStore.token);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (authStore.isLoggedIn) {
      fetchOrders();
    }
  }, [authStore.isLoggedIn, authStore.token]);

  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return dateString; // Возвращаем исходную строку, если дата невалидна
      }
      
      const day = date.getDate().toString().padStart(2, '0');
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const year = date.getFullYear();
      const hours = date.getHours().toString().padStart(2, '0');
      const minutes = date.getMinutes().toString().padStart(2, '0');
      
      return `${day}.${month}.${year}, ${hours}:${minutes}`;
    } catch (e) {
      return dateString;
    }
  };

  const renderOrderItem = ({ item }) => (
    <TouchableOpacity style={styles.orderItem}
    onPress={() => navigation.navigate('OrderDetail', { orderId: item.id })}
  >
      <View style={styles.orderHeader}>
        <Text style={styles.orderNumber}>Заказ №{item.order_number}</Text>
        <Text style={[
          styles.orderStatus,
          item.status === 'Отменён (Удален)' && styles.statusCancelled,
          item.status === 'Завершен' && styles.statusDelivered
        ]}>
          {getStatusText(item.status)}
        </Text>
      </View>
      
      <Text style={styles.orderDate}>
        {formatDate(item.created_at)}
      </Text>
      
      <View style={styles.orderFooter}>
        <Text style={styles.orderPrice}>{item.total_amount} ₽</Text>
        <Icon name="chevron-right" size={20} color="#999" />
      </View>
    </TouchableOpacity>
  );

  const getStatusText = (status) => {
    const statusMap = {
      'new': 'Новый',
      'processing': 'В обработке',
      'shipped': 'Отправлен',
      'delivered': 'Доставлен',
      'cancelled': 'Отменен'
    };
    return statusMap[status] || status;
  };

  if (!authStore.isLoggedIn) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center' }]}>
        <Icon name="error-outline" size={50} color="#4E9F3D" style={styles.authIcon} />
        <Text style={styles.authMessage}>Для просмотра заказов необходимо авторизоваться</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center' }]}>
        <ActivityIndicator size="large" color="#4E9F3D" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center' }]}>
        <Icon name="error-outline" size={50} color="#FF3B30" style={styles.errorIcon} />
        <Text style={styles.errorText}>Ошибка при загрузке заказов</Text>
        <Text style={styles.errorDetail}>{error}</Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <FlatList
        data={ordersStore.orders}
        renderItem={renderOrderItem}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Icon name="shopping-bag" size={50} color="#CCCCCC" style={styles.emptyIcon} />
            <Text style={styles.emptyText}>У вас пока нет заказов</Text>
          </View>
        }
      />
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  listContent: {
    padding: 16,
  },
  orderItem: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  orderNumber: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  orderStatus: {
    fontSize: 14,
    color: '#4E9F3D',
    fontWeight: '500',
  },
  statusCancelled: {
    color: '#FF3B30',
  },
  statusDelivered: {
    color: '#007AFF',
  },
  orderDate: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
  },
  orderFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    paddingTop: 12,
  },
  orderPrice: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
  },
  authMessage: {
    fontSize: 16,
    textAlign: 'center',
    margin: 20,
    color: '#666',
    maxWidth: '80%',
  },
  errorText: {
    fontSize: 16,
    textAlign: 'center',
    margin: 20,
    color: '#FF3B30',
    maxWidth: '80%',
  },
  errorDetail: {
    fontSize: 14,
    textAlign: 'center',
    marginHorizontal: 20,
    color: '#666',
    maxWidth: '80%',
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 16,
    color: '#666',
  },
  authIcon: {
    marginBottom: 16,
  },
  errorIcon: {
    marginBottom: 16,
  },
  emptyIcon: {
    marginBottom: 16,
    opacity: 0.5,
  },
});

export default OrdersScreen;
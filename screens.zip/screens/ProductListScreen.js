import 'react-native-gesture-handler';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useNavigation } from '@react-navigation/native';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  Animated,
  TouchableOpacity,
  RefreshControl,
  ScrollView,
  Dimensions
} from 'react-native';
import _ from 'lodash';
import FastImage from "@d11/react-native-fast-image";
import { observer } from 'mobx-react-lite';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import CustomLoader from '../components/CustomLoader';
import BottomSheet, { BottomSheetView, BottomSheetBackdrop } from "@gorhom/bottom-sheet";
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useStores } from '../useStores';
import { Haptics } from 'react-native-nitro-haptics';

const { width } = Dimensions.get('window');
const CARD_MARGIN = 8;
const CARD_WIDTH = (width - CARD_MARGIN * 3) / 2;
const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

const ProductListScreen = observer(() => {
  const navigation = useNavigation();
  const DEFAULT_IMAGE = 'https://api.koleso.app/public/img/no-image.jpg';
  const { authStore, favoritesStore, productStore } = useStores();
  
  const [backdropOpacity, setBackdropOpacity] = useState(0);
  const [isBottomSheetOpen, setIsBottomSheetOpen] = useState(false);
  
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const scrollY = useRef(new Animated.Value(0)).current;
  const flatListRef = useRef(null);
  const sheetRef = useRef(null);
  
  const insets = useSafeAreaInsets();
  const statusBarHeight = insets.top;



  useEffect(() => {
    console.log('Products in store:', productStore.products.length);
    console.log('Loading state:', productStore.loading);
  }, [productStore.products, productStore.loading]);

  // Анимации для фильтров
  const filterTranslateY = scrollY.interpolate({
    inputRange: [-50, 0, 50],
    outputRange: [0, 0, -50],
    extrapolate: 'clamp',
  });
  
  const filterOpacity = scrollY.interpolate({
    inputRange: [-30, 0, 30],
    outputRange: [1, 1, 0],
    extrapolate: 'clamp',
  });

  const handleScroll = Animated.event(
    [{ nativeEvent: { contentOffset: { y: scrollY } } }],
    { useNativeDriver: true }
  );

  const snapPoints = useMemo(() => ["35%"], []);

  const renderBackdrop = useCallback(
    (props) => (
      <BottomSheetBackdrop
        {...props}
        opacity={backdropOpacity}
        enableTouchThrough={false}
        appearsOnIndex={0}
        disappearsOnIndex={-1}
        style={styles.backdrop}
      />
    ),
    [backdropOpacity]
  );

  useEffect(() => {
    const loadData = async () => {
      try {
        // Сначала устанавливаем opacity в 0 перед загрузкой
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 0,
          useNativeDriver: true,
        }).start();
        
        await productStore.fetchProducts(true);
        
        // После загрузки плавно показываем контент
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }).start();
      } catch (error) {
        console.error('Error loading products:', error);
        // В случае ошибки тоже показываем контент
        fadeAnim.setValue(1);
      }
    };
    
    loadData();
    
    return () => {
      productStore.reset();
      // Отменяем анимации при размонтировании
      fadeAnim.setValue(1);
    };
  }, []);

  const loadMore = useCallback(() => {
    if (!productStore.isBackgroundLoad && !productStore.loading && productStore.hasMore) {
      productStore.fetchProducts(false);
    }
  }, [productStore.isBackgroundLoad, productStore.loading, productStore.hasMore]);

  const handleRefresh = useCallback(() => {
    if (!productStore.isManualRefresh && !productStore.isInitialLoad) {
      productStore.fetchProducts(true);
    }
  }, [productStore.isManualRefresh, productStore.isInitialLoad]);

  const renderSeasonIcon = (season) => {
    if (!season) return null;
    
    const seasonLower = season.toLowerCase();
    
    if (seasonLower.includes('лет')) {
      return <Ionicons name="sunny" size={14} color="#FFA500" style={styles.seasonIcon} />;
    } else if (seasonLower.includes('зим')) {
      return <Ionicons name="snow" size={14} color="#4682B4" style={styles.seasonIcon} />;
    } else if (seasonLower.includes('всесезон')) {
      return <MaterialCommunityIcons name="weather-partly-cloudy" size={14} color="#808080" style={styles.seasonIcon} />;
    }
    return null;
  };

  const formatTireSize = (width, profile, diameter) => {
    const formatNumber = (num) => {
      const number = parseFloat(num);
      return number % 1 === 0 ? number.toString() : num;
    };

    return `${formatNumber(width)}/${formatNumber(profile)} R${formatNumber(diameter)}`;
  };


  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      favoritesStore.refreshFavorites(authStore.token);
      setLocalFavorites(favoritesStore.items);
    });
  
    return unsubscribe;
  }, [navigation]);

  const [localFavorites, setLocalFavorites] = useState({});

  const isFavorite = useCallback((productId) => {
    // Объединяем оптимистичное состояние и состояние из хранилища
    if (localFavorites.hasOwnProperty(productId)) {
      return localFavorites[productId];
    }
    return favoritesStore.items.some(item => item.product_id == productId);
  }, [localFavorites, favoritesStore.items]);

  const toggleFavorite = useCallback(async (product) => {
    Haptics.impact('medium');
    const productId = product.id;
    const newValue = !isFavorite(productId);
    
    // Оптимистичное обновление
    setLocalFavorites(prev => ({ ...prev, [productId]: newValue }));
    
    try {
      if (newValue) {
        await favoritesStore.addToFavorites(product, authStore.token); // Передаем весь product
     
      } else {
        await favoritesStore.removeFromFavorites(productId, authStore.token);
      }
    } catch (error) {
      // Откатываем при ошибке
      setLocalFavorites(prev => ({ ...prev, [productId]: !newValue }));
    }
  }, [authStore.token, isFavorite]);

  const renderItem = useCallback(({ item }) => {
    
  
    return (
      <TouchableOpacity 
        style={styles.itemContainer} 
        onPress={() => navigation.navigate('Product', { productId: item.id })}
      >
        <View style={styles.imageContainer}>
          <FastImage
            style={styles.productImage}
            source={{ uri: item.image_url || DEFAULT_IMAGE }}
            resizeMode="contain"
          />
          <TouchableOpacity 
            style={styles.favoriteButton}
            onPress={(e) => {
              e.stopPropagation();
              toggleFavorite(item);
            }}
          >
            <Ionicons
              name={isFavorite(item.id) ? "heart" : "heart-outline"}
              size={24}
              color={isFavorite(item.id) ? "#FF3B30" : "#000"}
            />
          </TouchableOpacity>
        </View>
        <View style={[styles.productInfo, { flex: 1 }]}>
          <Text style={styles.productName} numberOfLines={2}>{item.name}</Text>
          <Text style={styles.productBrand} numberOfLines={1}>
            {item.brand} {item.model}
          </Text>
          
          <Text style={styles.productPrice}>{parseFloat(item.price).toFixed(0)} ₽</Text>
          
          {item.out_of_stock ? (
            <Text style={styles.outOfStock}>Нет в наличии</Text>
          ) : (
            <Text style={styles.inStock}>В наличии</Text>
          )}
          
          {item.category === 'Автошины' && (
            <View style={styles.specsContainer}>
              <Text style={styles.specText}>{formatTireSize(item.width, item.profile, item.diameter)}</Text>
              {item.season && (
                <View style={styles.seasonContainer}>
                 {renderSeasonIcon(item.season)}
                  <Text style={styles.specText}> {item.season}</Text>
                </View>
              )}
              {item.spiked === 1 && <Text style={styles.specText}>Шипованные</Text>}
              {item.runflat_tech && <Text style={styles.specText}>{item.runflat_tech}</Text>}
            </View>
          )}
        </View>
        </TouchableOpacity>
  );
}, [toggleFavorite]);

  const keyExtractor = useCallback((item) => `product-${item.sku}-${item.last_sync_at || '0'}`, []);

  const openFilters = () => {
    isBottomSheetOpen ? sheetRef.current?.close() : null;
    navigation.navigate('FilterScreen', {
      initialFilters: productStore.filters,
      onApplyFilters: (newFilters) => {
        productStore.setFilters(newFilters);
        productStore.fetchProducts(true);
      }
    });
  };

  const handleSortSelect = (sortType) => {
    productStore.setSort(sortType);
    productStore.fetchProducts(true);
    handleClose();
  };

  const handleSheetChange = useCallback((index) => {
    const isOpen = index >= 0;
    setIsBottomSheetOpen(isOpen);
    setBackdropOpacity(isOpen ? 0.5 : 0);
  }, []);

  const handleClose = useCallback(() => {
    sheetRef.current?.close();
  }, []);

  const filterLabels = {
    category: 'Категория',
    brand: 'Бренд',
    diameter: 'Диаметр',
    inStockOnly: 'В наличии',
    season: 'Сезон',
    spiked: 'Шипы',
    runflat_tech: 'RunFlat',
    sort: 'Сортировка',
  };

  const filtersList = [
    { 
      id: 'sort', 
      icon: 'swap-vertical-outline', 
      onPress: () => isBottomSheetOpen ? sheetRef.current?.close() : sheetRef.current?.expand(),
      active: productStore.filters.sort !== null
    },
    { 
      id: 'options', 
      icon: 'options-outline', 
      onPress: openFilters,
      active: Object.entries(productStore.filters).some(([key, value]) => 
        key !== 'sort' && value !== null && value !== false && value.length !== 0
      )
    },
    { 
      id: 'auto', 
      icon: 'car', 
      onPress: () => navigation.navigate('FilterAuto', { presentation: 'modal' }),
      active: productStore.carFilter !== null
    },
  ];

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
    <View style={[styles.container, { paddingTop: statusBarHeight }]}>
        {/* Фильтры */}
        <Animated.View style={[
          styles.filterWrapper,
          {
            transform: [{ translateY: filterTranslateY }],
            opacity: filterOpacity,
            zIndex: 10,
            top: statusBarHeight,
          }
        ]}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filterContainer}
          >
            {filtersList.map((filter) => (
  <TouchableOpacity
    key={filter.id}
    style={[
      styles.filterItem,
      filter.active && styles.activeFilter
    ]}
    onPress={filter.onPress}
  >
    {filter.iconSet ? (
      <filter.iconSet
        name={filter.icon}
        size={20}
        color={filter.active ? '#fff' : '#000'}
      />
    ) : (
      <Ionicons
        name={filter.icon}
        size={20}
        color={filter.active ? '#fff' : '#000'}
      />
    )}
  </TouchableOpacity>
))}
{productStore.carFilter && (
  <TouchableOpacity
    style={[styles.filterItem, styles.activeFilter]}
    onPress={() => productStore.clearCarFilter()}
  >
    <Text style={styles.activeFilterText}>
      {`Авто: ${productStore.carFilter.marka} ${productStore.carFilter.model}`}
    </Text>
    <Ionicons name="close-circle-outline" size={16} color="#fff" />
  </TouchableOpacity>
)}
            {Object.entries(productStore.filters)
              .filter(([key, value]) => value !== null && value !== false && value.length !== 0 && key !== 'sort')
              .map(([key, value]) => {
                const label = filterLabels[key] || key;
                if(key === 'spiked') {
                  if (value === 0) value = 'Без шипов';
                  else if (value === 1) value = 'Шипованные';
                  else if(value.length === 2) value = 'Все';
                }
                const displayValue = Array.isArray(value) ? value.join(', ') : value;
                
                return (
                  <TouchableOpacity
                    key={key}
                    style={[styles.filterItem, styles.activeFilter]}
                    onPress={() => productStore.removeFilter(key)}
                  >
                    <Text style={styles.activeFilterText}>{`${label}: ${displayValue}`}</Text>
                    <Ionicons name="close-circle-outline" size={16} color="#fff" />
                  </TouchableOpacity>
                );
              })}
          </ScrollView>
        </Animated.View>

        {productStore.isInitialLoad && !productStore.isManualRefresh && (
          <View style={styles.fullscreenLoader}>
            <CustomLoader 
              color="#005BFF" 
              size={48}
            />
          </View>
        )}

        <Animated.View style={[styles.listContainer, { opacity: fadeAnim }]}>
          <AnimatedFlatList
            ref={flatListRef}
            data={productStore.products}
            contentContainerStyle={{ paddingTop: 60 }}
            onScroll={handleScroll}
            scrollEventThrottle={16}
            renderItem={renderItem}
            keyExtractor={keyExtractor}
            numColumns={2}
            columnWrapperStyle={styles.columnWrapper}
            initialNumToRender={8}
            maxToRenderPerBatch={8}
            windowSize={10}
            onEndReached={_.throttle(loadMore, 1000)}
            onEndReachedThreshold={0.5}
            refreshControl={
              <RefreshControl
                refreshing={productStore.isManualRefresh}
                onRefresh={handleRefresh}
                progressViewOffset={60}
              />
            }
            ListFooterComponent={
              productStore.isBackgroundLoad ? (
                <View style={styles.footerLoader}>
                  <CustomLoader size={25} />
                </View>
              ) : null
            }
            ListEmptyComponent={
              !productStore.loading && (
                <View style={styles.emptyContainer}>
                  <Text style={styles.emptyText}>Товары не найдены. Попробуйте изменить фильтры.</Text>
                </View>
              )
            }
          />
        </Animated.View>

        <BottomSheet
          ref={sheetRef}
          index={-1}
          snapPoints={snapPoints}
          enablePanDownToClose={true}
          onChange={handleSheetChange}
          backdropComponent={renderBackdrop}
          backgroundStyle={styles.bottomSheetBackground}
          handleIndicatorStyle={styles.bottomSheetHandle}
        >
          <BottomSheetView style={styles.bottomSheetContent}>
            <Text style={styles.bottomSheetTitle}>Сортировка</Text>
            
            <TouchableOpacity 
              style={styles.sortOption}
              onPress={() => handleSortSelect('price_asc')}
            >
              <Ionicons
                name={productStore.filters.sort === 'price_asc' ? 'radio-button-on' : 'radio-button-off'}
                size={24}
                color={productStore.filters.sort === 'price_asc' ? '#005BFF' : '#ccc'}
              />
              <Text style={styles.sortOptionText}>По возрастанию цены</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.sortOption}
              onPress={() => handleSortSelect('price_desc')}
            >
              <Ionicons
                name={productStore.filters.sort === 'price_desc' ? 'radio-button-on' : 'radio-button-off'}
                size={24}
                color={productStore.filters.sort === 'price_desc' ? '#005BFF' : '#ccc'}
              />
              <Text style={styles.sortOptionText}>По убыванию цены</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.sortOption}
              onPress={() => handleSortSelect(null)}
            >
              <Ionicons
                name={productStore.filters.sort === null ? 'radio-button-on' : 'radio-button-off'}
                size={24}
                color={productStore.filters.sort === null ? '#006363' : '#ccc'}
              />
              <Text style={styles.sortOptionText}>Без сортировки</Text>
            </TouchableOpacity>
          </BottomSheetView>
        </BottomSheet>
      </View>
    </GestureHandlerRootView>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  filterWrapper: {
    position: 'absolute',
    left: 0,
    right: 0,
    backgroundColor: '#fff',
    paddingVertical: 5,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  filterContainer: {
    paddingHorizontal: 12,
    alignItems: 'center',
    height: 40,
  },
  filterItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginRight: 8,
    backgroundColor: '#f5f5f5',
    borderRadius: 24,
    height: 36,
  },
  activeFilter: {
    backgroundColor: '#006363',
  },
  activeFilterText: {
    color: '#fff',
    marginRight: 4,
    fontSize: 12,
  },
  filterCloseIcon: {
    marginLeft: 4,
  },
  listContainer: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
  itemContainer: {
    width: CARD_WIDTH,
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
    marginBottom: CARD_MARGIN,
  },
  productImage: {
    width: '100%',
    height: CARD_WIDTH - 20,
    borderRadius: 4,
    marginBottom: 8,
  },
productInfo: {
    flex: 1,
    justifyContent: 'space-between', // Добавляем это свойство
},
productName: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
    color: '#333',
    minHeight: 36, // Изменяем height на minHeight
    lineHeight: 16, // Добавляем lineHeight для лучшего отображения
},
productBrand: {
    fontSize: 12,
    color: '#666',
    marginBottom: 6,
    flexShrink: 1, // Добавляем это свойство
},
  productPrice: {
    fontSize: 15,
    fontWeight: '700',
    color: '#000',
    marginBottom: 4,
  },
  inStock: {
    color: '#4CAF50',
    fontSize: 12,
    fontWeight: '500',
  },
  outOfStock: {
    color: '#F44336',
    fontSize: 12,
    fontWeight: '500',
  },
  specsContainer: {
    marginTop: 6,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  specText: {
    fontSize: 10,
    color: '#555',
    marginRight: 6,
    marginBottom: 4,
    paddingHorizontal: 4,
    paddingVertical: 2,
    backgroundColor: '#f0f0f0',
    borderRadius: 4,
  },
  seasonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  seasonIcon: {
    marginRight: 2,
  },
  columnWrapper: {
    justifyContent: 'space-between',
    paddingHorizontal: CARD_MARGIN,
  },
  fullscreenLoader: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    zIndex: 10,
  },
  footerLoader: {
    width: '100%',
    paddingVertical: 10,
    alignItems: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 15,
    color: '#666',
  },
  bottomSheetBackground: {
    backgroundColor: '#fff',
    borderRadius: 20,
  },
  bottomSheetHandle: {
    backgroundColor: '#ccc',
    width: 40,
    height: 4,
  },
  bottomSheetContent: {
    padding: 20,
  },
  bottomSheetTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 20,
    textAlign: 'center',
  },
  sortOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  sortOptionText: {
    fontSize: 16,
    marginLeft: 12,
  },
  backdrop: {
    backgroundColor: 'rgba(0, 0, 0, 0)',
  },
  imageContainer: {
    position: 'relative',
    backgroundColor: '#fff',
  },
  favoriteButton: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  favoriteIcon: {
    
    textShadowColor: 'rgb(0, 0, 0)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 1,
    backgroundColor: '#fff',
  },
});

export default React.memo(ProductListScreen);